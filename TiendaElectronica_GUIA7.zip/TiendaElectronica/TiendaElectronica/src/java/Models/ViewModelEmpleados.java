package Models;


import java.util.Date;

public class ViewModelEmpleados {

    /**
     * @return the EmpleadoId
     */
    public int getEmpleadoId() {
        return EmpleadoId;
    }

    /**
     * @param EmpleadoId the EmpleadoId to set
     */
    public void setEmpleadoId(int EmpleadoId) {
        this.EmpleadoId = EmpleadoId;
    }

    /**
     * @return the Nombres
     */
    public String getNombres() {
        return Nombres;
    }

    /**
     * @param Nombres the Nombres to set
     */
    public void setNombres(String Nombres) {
        this.Nombres = Nombres;
    }

    /**
     * @return the Apellidos
     */
    public String getApellidos() {
        return Apellidos;
    }

    /**
     * @param Apellidos the Apellidos to set
     */
    public void setApellidos(String Apellidos) {
        this.Apellidos = Apellidos;
    }

    /**
     * @return the Email
     */
    public String getEmail() {
        return Email;
    }

    /**
     * @param Email the Email to set
     */
    public void setEmail(String Email) {
        this.Email = Email;
    }

    /**
     * @return the DUI
     */
    public String getDUI() {
        return DUI;
    }

    /**
     * @param DUI the DUI to set
     */
    public void setDUI(String DUI) {
        this.DUI = DUI;
    }

    /**
     * @return the Telefono
     */
    public String getTelefono() {
        return Telefono;
    }

    /**
     * @param Telefono the Telefono to set
     */
    public void setTelefono(String Telefono) {
        this.Telefono = Telefono;
    }

    /**
     * @return the FechaNac
     */
    public Date getFechaNac() {
        return FechaNac;
    }

    /**
     * @param FechaNac the FechaNac to set
     */
    public void setFechaNac(Date FechaNac) {
        this.FechaNac = FechaNac;
    }

    /**
     * @return the Direccion
     */
    public String getDireccion() {
        return Direccion;
    }

    /**
     * @param Direccion the Direccion to set
     */
    public void setDireccion(String Direccion) {
        this.Direccion = Direccion;
    }

    /**
     * @return the CargoId
     */
    public int getCargoId() {
        return CargoId;
    }

    /**
     * @param CargoId the CargoId to set
     */
    public void setCargoId(int CargoId) {
        this.CargoId = CargoId;
    }

    /**
     * @return the empleadoId
     */

    private int EmpleadoId;
    private String Nombres;
    private String Apellidos;
    private String Email;
    private String DUI;
    private String Telefono;
    private Date FechaNac;
    private String Direccion;
    private int CargoId;
   

}
